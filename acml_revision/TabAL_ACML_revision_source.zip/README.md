# TabAL expanded revision

The package contains the expanded, double-blind manuscript and all generated figures.

- `main.tex`: primary source; `\anonymoustrue` is enabled for review.
- `main.pdf`: compiled 12-page draft, including references and appendices.
- `references.bib`: bibliography with the three reviewer-identified related studies.
- `figures/`: publication figures in PDF and PNG.
- `make_revision_figures.py`: reproducible figure-generation script.
- `secondary_metrics_summary.csv` and `paired_representation_effects.csv`: analysis outputs used for figures and tables.
- `REVIEW_RESPONSE.md`: point-by-point change log.

Compile from this directory with:

```bash
tectonic main.tex --keep-logs --keep-intermediates
```

The document currently retains the source manuscript’s NeurIPS-style wrapper so the scientific revision can be reviewed directly. Before an ACML submission, transfer the content into the official ACML template and recheck pagination. ACML 2026 requires anonymization and counts references and appendices within its 16-page conference-track limit.
